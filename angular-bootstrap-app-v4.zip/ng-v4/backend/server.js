/*
  backend/server.js
  Req #6: API Express — array en memoria, GET y POST
*/

const express = require('express');
const cors    = require('cors');

const app  = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

let tasks = [
  { id: 1, nombre: 'Tarea desde la API',   descripcion: 'Cargada al iniciar el servidor', categoria: 'Backend',    fechaCreacion: new Date().toISOString() },
  { id: 2, nombre: 'Integrar con Angular', descripcion: 'Consumir esta API con HttpClient', categoria: 'Desarrollo', fechaCreacion: new Date().toISOString() },
];
let nextId = 3;

/* GET /api/tasks — Req #6: retorna el array */
app.get('/api/tasks', (req, res) => {
  console.log(`[GET /api/tasks] ${tasks.length} tareas`);
  res.json(tasks);
});

/* POST /api/tasks — Req #6: agrega elemento recibiendo JSON */
app.post('/api/tasks', (req, res) => {
  const { nombre, descripcion, categoria } = req.body;
  if (!nombre || !descripcion)
    return res.status(400).json({ error: 'nombre y descripcion son requeridos' });

  const nueva = { id: nextId++, nombre, descripcion, categoria: categoria || 'General', fechaCreacion: new Date().toISOString() };
  tasks.push(nueva);
  console.log(`[POST /api/tasks] "${nueva.nombre}" id=${nueva.id}`);
  res.status(201).json(nueva);
});

/* DELETE /api/tasks/:id */
app.delete('/api/tasks/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const antes = tasks.length;
  tasks = tasks.filter(t => t.id !== id);
  if (tasks.length === antes) return res.status(404).json({ error: 'No encontrado' });
  res.json({ ok: true });
});

app.listen(PORT, () => console.log(`✅ API Express en http://localhost:${PORT}`));

/*
  cypress/e2e/01-login.cy.js
  Req #9: Test Cypress #1 — Flujo de autenticación (login / logout / guard)
*/

describe('01 — Autenticación', () => {

  it('redirige a /login cuando el usuario no está autenticado', () => {
    cy.visit('/tareas');
    cy.url().should('include', '/login');
    cy.get('h4').should('contain', 'Iniciar Sesión');
  });

  it('muestra error con credenciales incorrectas', () => {
    cy.visit('/login');
    cy.get('input[formControlName="usuario"]').type('usuario_incorrecto');
    cy.get('input[formControlName="password"]').type('clave_erronea');
    cy.get('button[type="submit"]').click();
    cy.get('.alert-danger').should('be.visible');
    cy.get('.alert-danger').should('contain', 'Credenciales incorrectas');
  });

  it('hace login exitoso con admin / 1234 y redirige a /tareas', () => {
    cy.visit('/login');
    cy.get('input[formControlName="usuario"]').clear().type('admin');
    cy.get('input[formControlName="password"]').clear().type('1234');
    cy.get('button[type="submit"]').click();
    cy.url().should('include', '/tareas');
    cy.get('app-header').should('exist');
  });

  it('muestra el botón de logout después de autenticarse', () => {
    cy.login();
    cy.get('button').contains('Salir').should('be.visible');
  });

  it('el logout redirige al login', () => {
    cy.login();
    cy.get('button').contains('Salir').click();
    cy.url().should('include', '/login');
  });

});

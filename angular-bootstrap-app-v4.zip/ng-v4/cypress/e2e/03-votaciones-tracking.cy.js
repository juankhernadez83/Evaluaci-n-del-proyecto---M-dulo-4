/*
  cypress/e2e/03-votaciones-tracking.cy.js
  Req #9: Test Cypress #3 — Sistema de votaciones y tracking de clicks
*/

describe('03 — Votaciones', () => {

  beforeEach(() => {
    cy.login();
    cy.get('a[routerLink="/votos"]').click();
    cy.url().should('include', '/votos');
  });

  it('muestra la página de votaciones con propuestas precargadas', () => {
    cy.get('h4').should('contain', 'Votación');
    cy.get('.card').should('have.length.greaterThan', 1);
  });

  it('incrementa votos positivos al hacer click en "A Favor"', () => {
    cy.get('.btn-success').first().then(($btn) => {
      // Leer el contador antes
      cy.get('.text-success').first().invoke('text').then((textAntes) => {
        const votosAntes = parseInt(textAntes.match(/\d+/)?.[0] ?? '0');
        cy.get('.btn-success').first().click();
        cy.get('.text-success').first().invoke('text').then((textDespues) => {
          const votosDespues = parseInt(textDespues.match(/\d+/)?.[0] ?? '0');
          expect(votosDespues).to.equal(votosAntes + 1);
        });
      });
    });
  });

  it('incrementa votos negativos al hacer click en "En Contra"', () => {
    cy.get('.text-danger').first().invoke('text').then((textAntes) => {
      const votosAntes = parseInt(textAntes.match(/\d+/)?.[0] ?? '0');
      cy.get('.btn-danger').first().click();
      cy.get('.text-danger').first().invoke('text').then((textDespues) => {
        const votosDespues = parseInt(textDespues.match(/\d+/)?.[0] ?? '0');
        expect(votosDespues).to.equal(votosAntes + 1);
      });
    });
  });

  it('muestra error de validación en el formulario de nueva propuesta', () => {
    cy.get('button[type="submit"]').click();
    cy.get('.text-danger').should('be.visible');
  });

  it('agrega una nueva propuesta al listado', () => {
    cy.get('input[formControlName="titulo"]').type('Nueva propuesta de test');
    cy.get('textarea[formControlName="descripcion"]').type('Descripción de la propuesta de Cypress');
    cy.get('button[type="submit"]').click();
    cy.get('.card').should('contain', 'Nueva propuesta de test');
  });

});

describe('03b — Tracking de Clicks', () => {

  beforeEach(() => {
    cy.login();
    cy.get('a[routerLink="/tracking"]').click();
    cy.url().should('include', '/tracking');
  });

  it('muestra la página de tracking correctamente', () => {
    cy.get('h4').should('contain', 'Tracking');
    cy.get('.badge').should('contain', 'Total:');
  });

  it('registra un click y muestra el contador reactivo', () => {
    cy.get('button').contains('Angular Click').click();
    cy.get('app-animated-card').should('exist');
    cy.get('app-animated-card').should('contain', 'btn-demo-angular');
  });

  it('incrementa el total de clicks con múltiples interacciones', () => {
    // Obtener total inicial
    cy.get('.badge').contains('Total:').invoke('text').then((textAntes) => {
      const totalAntes = parseInt(textAntes.match(/\d+/)?.[0] ?? '0');

      cy.get('button').contains('NgRx Click').click();
      cy.get('button').contains('Bootstrap Click').click();
      cy.get('button').contains('Dexie Click').click();

      cy.get('.badge').contains('Total:').invoke('text').then((textDespues) => {
        const totalDespues = parseInt(textDespues.match(/\d+/)?.[0] ?? '0');
        expect(totalDespues).to.be.greaterThan(totalAntes);
      });
    });
  });

  it('el botón Reset limpia los contadores', () => {
    cy.get('button').contains('Angular Click').click();
    cy.get('button').contains('🔄 Reset').click();
    cy.get('h4').parent().find('p').should('contain', 'Haz click');
  });

});

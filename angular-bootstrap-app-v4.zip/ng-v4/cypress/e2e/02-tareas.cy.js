/*
  cypress/e2e/02-tareas.cy.js
  Req #9: Test Cypress #2 — Gestión de tareas (formulario reactivo, NgRx, validaciones)
*/

describe('02 — Gestión de Tareas', () => {

  beforeEach(() => {
    cy.login();
    cy.url().should('include', '/tareas');
  });

  it('muestra la página de tareas con el formulario visible', () => {
    cy.get('app-task-form').should('exist');
    cy.get('form[ng-reflect-form]').should('exist');
  });

  it('muestra errores de validación al intentar enviar el formulario vacío', () => {
    cy.get('button[type="submit"]').first().click();
    cy.get('.text-danger').should('be.visible');
    cy.get('.text-danger').first().should('contain', 'Requerido');
  });

  it('muestra error de minPalabras cuando el nombre tiene menos de 2 palabras', () => {
    cy.get('input[formControlName="nombre"]').type('Nombre');
    cy.get('input[formControlName="nombre"]').blur();
    cy.get('.text-warning').should('be.visible');
    cy.get('.text-warning').should('contain', 'palabras');
  });

  it('muestra el formulario como válido con datos correctos', () => {
    cy.get('input[formControlName="nombre"]').type('Estudiar Angular Testing');
    cy.get('textarea[formControlName="descripcion"]').type('Aprender Jasmine Cypress y pruebas unitarias');
    cy.get('.text-success').should('contain', 'válido');
  });

  it('navega entre las secciones del menú correctamente', () => {
    cy.get('a[routerLink="/votos"]').click();
    cy.url().should('include', '/votos');
    cy.get('h4').should('contain', 'Votación');

    cy.get('a[routerLink="/tracking"]').click();
    cy.url().should('include', '/tracking');
    cy.get('h4').should('contain', 'Tracking');
  });

});

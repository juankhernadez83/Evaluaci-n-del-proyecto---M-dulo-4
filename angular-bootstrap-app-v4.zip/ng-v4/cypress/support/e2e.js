// cypress/support/e2e.js
// Comandos personalizados y configuración global de Cypress

// Comando para hacer login de forma rápida
Cypress.Commands.add('login', () => {
  cy.visit('/login');
  cy.get('input[formControlName="usuario"]').clear().type('admin');
  cy.get('input[formControlName="password"]').clear().type('1234');
  cy.get('button[type="submit"]').click();
  cy.url().should('include', '/tareas');
});

// Silenciar errores de Mapbox token en tests
Cypress.on('uncaught:exception', (err) => {
  if (err.message.includes('mapbox') || err.message.includes('token')) {
    return false;
  }
});

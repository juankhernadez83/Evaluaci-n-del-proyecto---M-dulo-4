/* app.module.ts — completo v3 */
import { NgModule }                         from '@angular/core';
import { BrowserModule }                    from '@angular/platform-browser';
import { BrowserAnimationsModule }          from '@angular/platform-browser/animations';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule }                 from '@angular/common/http';
import { StoreModule }                      from '@ngrx/store';
import { StoreDevtoolsModule }              from '@ngrx/store-devtools';
import { NgxMapboxGLModule }                from 'ngx-mapbox-gl';

import { AppRoutingModule }   from './app-routing.module';
import { taskReducer }        from './store/reducers/task.reducer';
import { voteReducer }        from './store/reducers/vote.reducer';
import { trackingReducer }    from './store/reducers/tracking.reducer';

import { APP_CONFIG, APP_CONFIG_VALUE }                           from './core/tokens';
import { LoggerService, ConsoleLoggerService, FileLoggerService } from './core/logger';

import { AppComponent }          from './app.component';
import { HeaderComponent }       from './components/header/header.component';
import { TaskFormComponent }     from './components/task-form/task-form.component';
import { AnimatedCardComponent } from './components/animated-card/animated-card.component';
import { ClickTrackerDirective } from './directives/click-tracker.directive';
import { LoginPageComponent }    from './pages/login-page/login-page.component';
import { HomePageComponent }     from './pages/home-page/home-page.component';
import { VotesPageComponent }    from './pages/votes-page/votes-page.component';
import { MapPageComponent }      from './pages/map-page/map-page.component';
import { TrackingPageComponent } from './pages/tracking-page/tracking-page.component';

@NgModule({
  declarations: [
    AppComponent, HeaderComponent, TaskFormComponent,
    AnimatedCardComponent, ClickTrackerDirective,
    LoginPageComponent, HomePageComponent, VotesPageComponent,
    MapPageComponent, TrackingPageComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,   /* Necesario para @angular/animations */
    FormsModule, ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule,
    NgxMapboxGLModule,         /* Req #1: ngx-mapbox-gl */
    StoreModule.forRoot({
      tasks:    taskReducer,
      votes:    voteReducer,
      tracking: trackingReducer  /* Req #7 */
    }),
    StoreDevtoolsModule.instrument({ maxAge: 25 })
  ],
  providers: [
    { provide: APP_CONFIG,        useValue:    APP_CONFIG_VALUE     },
    { provide: LoggerService,     useClass:    ConsoleLoggerService  },
    ConsoleLoggerService,
    { provide: FileLoggerService, useExisting: ConsoleLoggerService },
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}

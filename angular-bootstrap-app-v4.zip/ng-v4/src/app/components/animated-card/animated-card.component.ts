/*
  components/animated-card/animated-card.component.ts

  Req #3: Componente con animación cuando una propiedad cambia.
  Usa Angular Animations (@angular/animations) para animar
  la transición entre estados "activo" e "inactivo".
*/
import {
  Component, Input, OnChanges, SimpleChanges
} from '@angular/core';
import {
  trigger, state, style, animate, transition
} from '@angular/animations';

@Component({
  selector: 'app-animated-card',
  templateUrl: './animated-card.component.html',
  styleUrls: ['./animated-card.component.scss'],
  animations: [
    /*
      Req #3: Animación "cardState" que se activa cuando la propiedad
      "activo" cambia. Transiciona entre estado 'inactivo' y 'activo'.
    */
    trigger('cardState', [

      state('inactivo', style({
        transform: 'scale(1)',
        opacity: 0.75,
        borderLeft: '4px solid #0f3460'
      })),

      state('activo', style({
        transform: 'scale(1.03)',
        opacity: 1,
        borderLeft: '4px solid #e94560'
      })),

      /* Req #3: Transición animada al cambiar de inactivo → activo */
      transition('inactivo => activo', animate('300ms ease-out')),

      /* Req #3: Transición animada al volver de activo → inactivo */
      transition('activo => inactivo', animate('200ms ease-in'))
    ]),

    /* Animación de entrada del componente */
    trigger('fadeIn', [
      transition(':enter', [
        style({ opacity: 0, transform: 'translateY(-12px)' }),
        animate('350ms ease-out', style({ opacity: 1, transform: 'translateY(0)' }))
      ])
    ])
  ]
})
export class AnimatedCardComponent implements OnChanges {

  /* Req #3: Al cambiar esta propiedad, se dispara la animación */
  @Input() activo: boolean = false;
  @Input() titulo: string  = '';
  @Input() valor:  number  = 0;
  @Input() icono:  string  = '📊';

  /* Estado de la animación — ligado al @trigger cardState */
  estadoAnimacion: 'activo' | 'inactivo' = 'inactivo';

  /*
    Req #3: ngOnChanges detecta cuando "activo" cambia
    y actualiza el estado de la animación.
  */
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['activo']) {
      this.estadoAnimacion = this.activo ? 'activo' : 'inactivo';
    }
  }
}

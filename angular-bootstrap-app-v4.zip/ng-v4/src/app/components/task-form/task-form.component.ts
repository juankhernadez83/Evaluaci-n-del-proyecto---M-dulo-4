/* components/task-form/task-form.component.ts — @Output + FormBuilder */
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators }       from '@angular/forms';
import { Item }                                      from '../../models/item.model';
import { minPalabras, noCaracteresEspeciales }       from '../../validators/custom.validators';

@Component({
  selector: 'app-task-form',
  templateUrl: './task-form.component.html',
  styleUrls: ['./task-form.component.scss']
})
export class TaskFormComponent implements OnInit {

  /** Req #1 (módulo anterior): @Output con EventEmitter */
  @Output() tareaNueva = new EventEmitter<Item>();

  tareaForm!: FormGroup;
  private nextId = 500;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.tareaForm = this.fb.group({
      nombre:      ['', [Validators.required, Validators.minLength(3), minPalabras(2), noCaracteresEspeciales]],
      descripcion: ['', [Validators.required, minPalabras(3)]],
      categoria:   ['Estudio', Validators.required]
    });
  }

  get nombre()      { return this.tareaForm.get('nombre')!; }
  get descripcion() { return this.tareaForm.get('descripcion')!; }
  get categoria()   { return this.tareaForm.get('categoria')!; }

  onSubmit(): void {
    if (this.tareaForm.invalid) { this.tareaForm.markAllAsTouched(); return; }
    const item: Item = {
      id: this.nextId++,
      nombre:      this.tareaForm.value.nombre.trim(),
      descripcion: this.tareaForm.value.descripcion.trim(),
      categoria:   this.tareaForm.value.categoria,
      fechaCreacion: new Date()
    };
    this.tareaNueva.emit(item);
    this.tareaForm.reset({ categoria: 'Estudio' });
  }
}

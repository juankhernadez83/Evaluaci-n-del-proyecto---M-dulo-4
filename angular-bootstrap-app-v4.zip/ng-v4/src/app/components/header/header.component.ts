/* components/header/header.component.ts — Req #7 original: @HostBinding */
import { Component, HostBinding } from '@angular/core';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  @HostBinding('class') hostClass = 'w-100 d-block';

  appNombre    = 'Mi Gestor de Tareas';
  appDescripcion = 'Angular · Bootstrap · NgRx · Dexie';
  version      = '2.0.0';

  constructor(public auth: AuthService) {}
}

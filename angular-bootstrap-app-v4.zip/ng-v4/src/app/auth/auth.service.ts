/* auth/auth.service.ts — Req #1 */
import { Injectable } from '@angular/core';
import { Router }     from '@angular/router';

@Injectable({ providedIn: 'root' })
export class AuthService {

  private _logueado = false;

  constructor(private router: Router) {
    this._logueado = sessionStorage.getItem('auth') === 'true';
  }

  /** Req #1: usado por el Guard */
  estaLogueado(): boolean { return this._logueado; }

  login(usuario: string, password: string): boolean {
    if (usuario === 'admin' && password === '1234') {
      this._logueado = true;
      sessionStorage.setItem('auth', 'true');
      return true;
    }
    return false;
  }

  logout(): void {
    this._logueado = false;
    sessionStorage.removeItem('auth');
    this.router.navigate(['/login']);
  }

  get nombreUsuario(): string { return this._logueado ? 'admin' : ''; }
}

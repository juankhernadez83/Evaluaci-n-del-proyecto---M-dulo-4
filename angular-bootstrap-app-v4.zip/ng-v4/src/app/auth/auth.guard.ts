/* auth/auth.guard.ts — Req #1 y #2 */
import { Injectable }          from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService }         from './auth.service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {

  constructor(private authService: AuthService, private router: Router) {}

  /** Req #1: consulta al servicio si el usuario está logueado */
  canActivate(): boolean {
    if (this.authService.estaLogueado()) return true;
    console.warn('[AuthGuard] No autenticado → /login');
    this.router.navigate(['/login']);
    return false;
  }
}

/* app-routing.module.ts */
import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard }            from './auth/auth.guard';
import { LoginPageComponent }   from './pages/login-page/login-page.component';
import { HomePageComponent }    from './pages/home-page/home-page.component';
import { VotesPageComponent }   from './pages/votes-page/votes-page.component';
import { MapPageComponent }     from './pages/map-page/map-page.component';
import { TrackingPageComponent } from './pages/tracking-page/tracking-page.component';

const routes: Routes = [
  { path: 'login',    component: LoginPageComponent },
  { path: 'tareas',   component: HomePageComponent,     canActivate: [AuthGuard] },
  { path: 'votos',    component: VotesPageComponent,    canActivate: [AuthGuard] },
  { path: 'mapa',     component: MapPageComponent,      canActivate: [AuthGuard] },
  { path: 'tracking', component: TrackingPageComponent, canActivate: [AuthGuard] },
  { path: '',         redirectTo: 'tareas', pathMatch: 'full' },
  { path: '**',       redirectTo: 'tareas' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}

/* validators/custom.validators.ts */
import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

/** Validador parametrizable: exige al menos N palabras */
export function minPalabras(minimo: number): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const palabras = (control.value || '').trim().split(/\s+/).filter((p: string) => p.length > 0);
    if (palabras.length < minimo)
      return { minPalabras: { requerido: minimo, actual: palabras.length } };
    return null;
  };
}

/** Validador: rechaza caracteres especiales */
export function noCaracteresEspeciales(control: AbstractControl): ValidationErrors | null {
  return /[<>&"'`]/.test(control.value || '') ? { caracteresEspeciales: true } : null;
}

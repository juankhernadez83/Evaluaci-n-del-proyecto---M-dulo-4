/*
  pages/tracking-page/tracking-page.component.ts
  Req #6: Usa la directiva appClickTracker con trackTag
  Req #7: Muestra contadores reactivos desde NgRx
*/
import { Component, OnInit } from '@angular/core';
import { Store }             from '@ngrx/store';
import { Observable }        from 'rxjs';
import { selectTrackingCounters, selectTotalClicks } from '../../store/selectors/app.selectors';
import { resetTracking }     from '../../store/actions/tracking.actions';

@Component({
  selector: 'app-tracking-page',
  templateUrl: './tracking-page.component.html',
  styleUrls: ['./tracking-page.component.scss']
})
export class TrackingPageComponent implements OnInit {

  /* Req #7: Observables del store — se actualizan reactivamente */
  contadores$!:  Observable<Record<string, number>>;
  totalClicks$!: Observable<number>;

  /* Para animar la tarjeta activa */
  tagActivo: string | null = null;

  constructor(private store: Store) {}

  ngOnInit(): void {
    this.contadores$  = this.store.select(selectTrackingCounters);
    this.totalClicks$ = this.store.select(selectTotalClicks);
  }

  objectKeys(obj: Record<string, number>): string[] {
    return Object.keys(obj);
  }

  resetear(): void {
    this.store.dispatch(resetTracking());
  }

  activarTag(tag: string): void {
    this.tagActivo = tag;
    setTimeout(() => this.tagActivo = null, 500);
  }
}

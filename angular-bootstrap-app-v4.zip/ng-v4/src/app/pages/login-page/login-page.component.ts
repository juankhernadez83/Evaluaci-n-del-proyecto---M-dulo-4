/* pages/login-page/login-page.component.ts */
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router }      from '@angular/router';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html'
})
export class LoginPageComponent {

  loginForm: FormGroup;
  errorMsg  = '';
  cargando  = false;

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {
    if (this.auth.estaLogueado()) this.router.navigate(['/tareas']);
    this.loginForm = this.fb.group({
      usuario:  ['admin', Validators.required],
      password: ['1234',  Validators.required]
    });
  }

  get usuario()  { return this.loginForm.get('usuario')!; }
  get password() { return this.loginForm.get('password')!; }

  onSubmit(): void {
    if (this.loginForm.invalid) { this.loginForm.markAllAsTouched(); return; }
    this.cargando = true;
    this.errorMsg = '';
    setTimeout(() => {
      const ok = this.auth.login(this.loginForm.value.usuario, this.loginForm.value.password);
      this.cargando = false;
      if (ok) this.router.navigate(['/tareas']);
      else this.errorMsg = '❌ Credenciales incorrectas. Usa admin / 1234';
    }, 500);
  }
}

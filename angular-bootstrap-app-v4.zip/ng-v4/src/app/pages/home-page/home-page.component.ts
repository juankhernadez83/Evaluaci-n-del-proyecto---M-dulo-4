/* pages/home-page/home-page.component.ts */
import { Component, OnInit, Inject } from '@angular/core';
import { Store }                     from '@ngrx/store';
import { Observable }                from 'rxjs';
import { Item }                      from '../../models/item.model';
import { TaskApiService }            from '../../services/task-api.service';
import { AppDatabase, TaskRecord }   from '../../db/app-database';
import { APP_CONFIG, AppConfig }     from '../../core/tokens';
import { selectAllTasks }            from '../../store/selectors/app.selectors';
import { AuthService }               from '../../auth/auth.service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent implements OnInit {

  tareas$!: Observable<Item[]>;
  cargando      = false;
  errorApi      = '';
  dexieRecords: TaskRecord[] = [];

  constructor(
    private store:      Store,
    private apiService: TaskApiService,
    private db:         AppDatabase,          /* Req #9: Dexie inyectada */
    public  auth:       AuthService,
    @Inject(APP_CONFIG) public config: AppConfig  /* Req #3 */
  ) {}

  ngOnInit(): void {
    this.tareas$ = this.store.select(selectAllTasks);
    this.cargarDesdeApi();
    this.cargarDesdeDexie();
  }

  cargarDesdeApi(): void {
    this.cargando = true;
    this.errorApi = '';
    this.apiService.getTareas().subscribe({
      next: () => { this.cargando = false; },
      error: () => {
        this.errorApi = '⚠️ No se pudo conectar con la API. Inicia el servidor con: node backend/server.js';
        this.cargando = false;
      }
    });
  }

  /** Req #6 anterior + Req #8: envía a la API, el servicio actualiza NgRx y Dexie */
  onTareaNueva(item: Item): void {
    const payload = { nombre: item.nombre, descripcion: item.descripcion, categoria: item.categoria };
    this.apiService.crearTarea(payload).subscribe({
      next: () => this.cargarDesdeDexie(),
      error: err => console.error('Error al crear:', err)
    });
  }

  eliminarTarea(id: number): void {
    this.apiService.eliminarTarea(id).subscribe({
      next: () => this.cargarDesdeDexie()
    });
  }

  async cargarDesdeDexie(): Promise<void> {
    this.dexieRecords = await this.db.obtenerTodas();
  }
}

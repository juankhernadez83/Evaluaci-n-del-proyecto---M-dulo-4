/*
  pages/map-page/map-page.component.ts

  Req #1: usa ngx-mapbox-gl y @types/mapbox-gl@0.49.0
  Req #2: marker en el mapa con popup al hacer click
*/
import { Component } from '@angular/core';

export interface MapMarker {
  id:          number;
  lng:         number;
  lat:         number;
  titulo:      string;
  descripcion: string;
  popupAbierto: boolean;
}

@Component({
  selector: 'app-map-page',
  templateUrl: './map-page.component.html',
  styleUrls: ['./map-page.component.scss']
})
export class MapPageComponent {

  /* Coordenadas iniciales del mapa — Buenos Aires, Argentina */
  mapCenter: [number, number] = [-58.3816, -34.6037];
  mapZoom = [11];

  /*
    Req #2: Marcadores con popup.
    Al hacer click en el marker se muestra el popup con titulo y descripcion.
  */
  markers: MapMarker[] = [
    {
      id: 1,
      lng: -58.3816,
      lat: -34.6037,
      titulo: '📍 Buenos Aires',
      descripcion: 'Capital de Argentina. Click en el marker para ver este popup.',
      popupAbierto: false
    },
    {
      id: 2,
      lng: -58.4173,
      lat: -34.5755,
      titulo: '🏛️ Palermo',
      descripcion: 'Barrio cultural con parques, restaurantes y vida nocturna.',
      popupAbierto: false
    },
    {
      id: 3,
      lng: -58.3731,
      lat: -34.6345,
      titulo: '⚽ La Boca',
      descripcion: 'Famoso barrio porteño, hogar del estadio de Boca Juniors.',
      popupAbierto: false
    }
  ];

  /* Req #2: Abre/cierra el popup del marker clickeado */
  togglePopup(marker: MapMarker): void {
    /* Cierra todos los demás */
    this.markers.forEach(m => {
      if (m.id !== marker.id) m.popupAbierto = false;
    });
    marker.popupAbierto = !marker.popupAbierto;
  }

  cerrarPopup(marker: MapMarker): void {
    marker.popupAbierto = false;
  }
}

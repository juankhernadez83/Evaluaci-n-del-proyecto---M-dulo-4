/* pages/votes-page/votes-page.component.ts — Req #10 */
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Store }    from '@ngrx/store';
import { Observable } from 'rxjs';
import { VoteItem } from '../../models/item.model';
import { agregarVoteItem, eliminarVoteItem, votarPositivo, votarNegativo } from '../../store/actions/task.actions';
import { selectAllVotes } from '../../store/selectors/app.selectors';

@Component({
  selector: 'app-votes-page',
  templateUrl: './votes-page.component.html',
  styleUrls: ['./votes-page.component.scss']
})
export class VotesPageComponent implements OnInit {

  voteItems$!: Observable<VoteItem[]>;
  voteForm!: FormGroup;
  private nextId = 100;

  constructor(private store: Store, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.voteItems$ = this.store.select(selectAllVotes);
    this.voteForm = this.fb.group({
      titulo:      ['', [Validators.required, Validators.minLength(5)]],
      descripcion: ['', Validators.required]
    });
  }

  get titulo()      { return this.voteForm.get('titulo')!; }
  get descripcion() { return this.voteForm.get('descripcion')!; }

  agregarItem(): void {
    if (this.voteForm.invalid) { this.voteForm.markAllAsTouched(); return; }
    const item: VoteItem = {
      id: this.nextId++,
      titulo:         this.voteForm.value.titulo.trim(),
      descripcion:    this.voteForm.value.descripcion.trim(),
      votosPositivos: 0,
      votosNegativos: 0
    };
    this.store.dispatch(agregarVoteItem({ item }));
    this.voteForm.reset();
  }

  onVotarPositivo(id: number): void { this.store.dispatch(votarPositivo({ id })); }
  onVotarNegativo(id: number): void { this.store.dispatch(votarNegativo({ id })); }
  eliminarItem(id: number):    void { this.store.dispatch(eliminarVoteItem({ id })); }

  calcularPorcentaje(item: VoteItem): number {
    const total = item.votosPositivos + item.votosNegativos;
    return total === 0 ? 50 : Math.round((item.votosPositivos / total) * 100);
  }
}

/*
  directives/click-tracker.directive.ts

  Req #4: Directiva personalizada para trackear/registrar clicks del usuario.
  Req #5: Recibe ElementRef por inyección de dependencias y se suscribe a eventos DOM.
  Req #6: Lee "tracking tags" del atributo del elemento DOM.
  Req #7: Despacha action a Redux para actualizar contadores reactivamente.
*/
import {
  Directive, ElementRef, Input,
  OnInit, OnDestroy, Inject
} from '@angular/core';
import { Store } from '@ngrx/store';
import { registrarClick } from '../store/actions/tracking.actions';

@Directive({
  /* Req #6: Se aplica como atributo appClickTracker en cualquier elemento */
  selector: '[appClickTracker]'
})
export class ClickTrackerDirective implements OnInit, OnDestroy {

  /*
    Req #6: El template pasa el "tracking tag" al input de la directiva.
    Ejemplo: <button appClickTracker trackTag="btn-agregar-tarea">
  */
  @Input() trackTag: string = 'sin-tag';

  /* Referencia al handler para poder removerlo en ngOnDestroy */
  private clickHandler!: () => void;

  constructor(
    /*
      Req #5: ElementRef inyectado por DI — referencia al elemento DOM nativo
      donde se aplica la directiva.
    */
    private el: ElementRef,

    /* Store NgRx para despachar la action (Req #7) */
    private store: Store
  ) {}

  ngOnInit(): void {
    /*
      Req #5: Suscripción al evento click del DOM usando addEventListener.
      La directiva escucha el evento nativo del ElementRef.nativeElement.
    */
    this.clickHandler = () => {
      const tag = this.trackTag || this.el.nativeElement.getAttribute('track-tag') || 'sin-tag';

      console.log(`[ClickTracker] Click registrado en tag: "${tag}"`,
        this.el.nativeElement);

      /*
        Req #7: Despacha action a Redux → el reducer incrementa el contador
        → el template se actualiza reactivamente con el nuevo valor.
      */
      this.store.dispatch(registrarClick({ tag }));
    };

    /* Req #5: addEventListener sobre el elemento DOM nativo */
    this.el.nativeElement.addEventListener('click', this.clickHandler);
  }

  ngOnDestroy(): void {
    /* Limpieza: remover el listener para evitar memory leaks */
    this.el.nativeElement.removeEventListener('click', this.clickHandler);
  }
}

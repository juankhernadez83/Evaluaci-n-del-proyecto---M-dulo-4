/* db/app-database.ts — Req #9: Base de datos Dexie */
import Dexie, { Table } from 'dexie';
import { Injectable }   from '@angular/core';

/** Req #9: Entidad persistida en IndexedDB */
export interface TaskRecord {
  id?:           number;   // auto-increment
  apiId:         number;
  nombre:        string;
  descripcion:   string;
  categoria:     string;
  fechaCreacion: string;
  sincronizado:  boolean;
}

/**
 * Req #9: Clase que hereda de Dexie — define la BD y su tabla "tasks".
 * Al ser @Injectable(providedIn:'root') puede inyectarse en servicios y componentes.
 */
@Injectable({ providedIn: 'root' })
export class AppDatabase extends Dexie {

  /** Req #9: Tabla de tareas con su tipo TypeScript */
  tasks!: Table<TaskRecord, number>;

  constructor() {
    super('AppDatabase');
    this.version(1).stores({
      tasks: '++id, apiId, nombre, sincronizado'
    });
  }

  async guardarTarea(record: Omit<TaskRecord, 'id'>): Promise<number> {
    return this.tasks.add(record as TaskRecord);
  }

  async obtenerTodas(): Promise<TaskRecord[]> {
    return this.tasks.toArray();
  }

  async eliminarPorApiId(apiId: number): Promise<void> {
    await this.tasks.where('apiId').equals(apiId).delete();
  }
}

/* store/selectors/app.selectors.ts */
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { TaskState }     from '../reducers/task.reducer';
import { VoteState }     from '../reducers/vote.reducer';
import { TrackingState } from '../reducers/tracking.reducer';

export const selectTaskState    = createFeatureSelector<TaskState>('tasks');
export const selectAllTasks     = createSelector(selectTaskState, s => s.items);

export const selectVoteState    = createFeatureSelector<VoteState>('votes');
export const selectAllVotes     = createSelector(selectVoteState, s => s.items);

export const selectTrackingState    = createFeatureSelector<TrackingState>('tracking');
export const selectTrackingCounters = createSelector(selectTrackingState, s => s.contadores);
export const selectTotalClicks      = createSelector(selectTrackingState, s => s.totalClicks);

/*
  store/reducers/tracking.reducer.ts
  Req #7: Reducer que mantiene contadores por tracking tag
  Req #8: Este reducer será probado con Jasmine (spec)
*/
import { createReducer, on } from '@ngrx/store';
import { registrarClick, resetTracking } from '../actions/tracking.actions';

export interface TrackingState {
  /* mapa tag → cantidad de clicks */
  contadores: Record<string, number>;
  totalClicks: number;
}

export const initialTrackingState: TrackingState = {
  contadores:  {},
  totalClicks: 0
};

export const trackingReducer = createReducer(
  initialTrackingState,

  /* Req #7: Incrementa el contador del tag recibido */
  on(registrarClick, (state, { tag }) => ({
    ...state,
    contadores: {
      ...state.contadores,
      [tag]: (state.contadores[tag] ?? 0) + 1
    },
    totalClicks: state.totalClicks + 1
  })),

  on(resetTracking, () => ({ ...initialTrackingState }))
);

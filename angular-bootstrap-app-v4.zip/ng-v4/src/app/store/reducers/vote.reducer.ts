/* store/reducers/vote.reducer.ts — Req #10 */
import { createReducer, on } from '@ngrx/store';
import { VoteItem }          from '../../models/item.model';
import { agregarVoteItem, eliminarVoteItem, votarPositivo, votarNegativo } from '../actions/task.actions';

export interface VoteState { items: VoteItem[]; }

export const initialVoteState: VoteState = {
  items: [
    { id: 1, titulo: 'Angular vs React',     descripcion: '¿Cuál framework prefieres?',         votosPositivos: 12, votosNegativos: 4  },
    { id: 2, titulo: 'TypeScript obligatorio',descripcion: '¿Debe ser estándar en todo proyecto?',votosPositivos: 20, votosNegativos: 3  },
    { id: 3, titulo: 'NgRx para todo',        descripcion: '¿Es necesario en apps pequeñas?',    votosPositivos: 5,  votosNegativos: 15 },
  ]
};

export const voteReducer = createReducer(
  initialVoteState,
  on(agregarVoteItem,  (state, { item }) => ({ ...state, items: [...state.items, item] })),
  on(eliminarVoteItem, (state, { id   }) => ({ ...state, items: state.items.filter(i => i.id !== id) })),
  on(votarPositivo, (state, { id }) => ({
    ...state,
    items: state.items.map(i => i.id === id ? { ...i, votosPositivos: i.votosPositivos + 1 } : i)
  })),
  on(votarNegativo, (state, { id }) => ({
    ...state,
    items: state.items.map(i => i.id === id ? { ...i, votosNegativos: i.votosNegativos + 1 } : i)
  }))
);

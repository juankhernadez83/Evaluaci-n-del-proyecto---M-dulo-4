/*
  src/app/store/reducers/reducers.spec.ts

  Req #8: Pruebas unitarias con Jasmine para TODOS los reducers.
  Los reducers son funciones puras: reciben (state, action) y retornan nuevo estado
  SIN mutar el original.
*/

import { taskReducer,     initialTaskState,     TaskState     } from './task.reducer';
import { voteReducer,     initialVoteState,     VoteState     } from './vote.reducer';
import { trackingReducer, initialTrackingState, TrackingState } from './tracking.reducer';

import { agregarTarea, eliminarTarea, cargarTareas }                    from '../actions/task.actions';
import { agregarVoteItem, eliminarVoteItem, votarPositivo, votarNegativo } from '../actions/task.actions';
import { registrarClick, resetTracking }                                from '../actions/tracking.actions';

import { Item, VoteItem } from '../../models/item.model';

/* ═══════════════════════════════════════════════════════════
   TASK REDUCER TESTS
   ═══════════════════════════════════════════════════════════ */
describe('taskReducer', () => {

  const itemA: Item = {
    id: 1, nombre: 'Tarea A', descripcion: 'Descripción A',
    categoria: 'Estudio', fechaCreacion: new Date()
  };
  const itemB: Item = {
    id: 2, nombre: 'Tarea B', descripcion: 'Descripción B',
    categoria: 'Desarrollo', fechaCreacion: new Date()
  };

  it('debe retornar el estado inicial cuando recibe una acción desconocida', () => {
    const state = taskReducer(undefined, { type: '@@UNKNOWN' } as any);
    expect(state).toEqual(initialTaskState);
    expect(state.items.length).toBe(0);
  });

  it('cargarTareas: debe reemplazar el array de items con los recibidos', () => {
    const state = taskReducer(initialTaskState, cargarTareas({ items: [itemA, itemB] }));
    expect(state.items.length).toBe(2);
    expect(state.items[0].nombre).toBe('Tarea A');
    expect(state.items[1].nombre).toBe('Tarea B');
  });

  it('agregarTarea: debe agregar un nuevo item al array', () => {
    const estadoConUno = taskReducer(initialTaskState, agregarTarea({ item: itemA }));
    expect(estadoConUno.items.length).toBe(1);
    expect(estadoConUno.items[0]).toEqual(itemA);

    const estadoConDos = taskReducer(estadoConUno, agregarTarea({ item: itemB }));
    expect(estadoConDos.items.length).toBe(2);
  });

  it('agregarTarea: NO debe mutar el estado original', () => {
    const estadoOriginal: TaskState = { items: [itemA] };
    const nuevoEstado = taskReducer(estadoOriginal, agregarTarea({ item: itemB }));

    /* El estado original no debe cambiar */
    expect(estadoOriginal.items.length).toBe(1);
    expect(nuevoEstado.items.length).toBe(2);
    expect(nuevoEstado).not.toBe(estadoOriginal); /* nueva referencia */
  });

  it('eliminarTarea: debe eliminar el item con el id indicado', () => {
    const estadoConDos: TaskState = { items: [itemA, itemB] };
    const resultado = taskReducer(estadoConDos, eliminarTarea({ id: 1 }));
    expect(resultado.items.length).toBe(1);
    expect(resultado.items[0].id).toBe(2);
  });

  it('eliminarTarea: no debe cambiar el estado si el id no existe', () => {
    const estadoConUno: TaskState = { items: [itemA] };
    const resultado = taskReducer(estadoConUno, eliminarTarea({ id: 999 }));
    expect(resultado.items.length).toBe(1);
  });

  it('eliminarTarea: NO debe mutar el estado original', () => {
    const estadoOriginal: TaskState = { items: [itemA, itemB] };
    const nuevoEstado = taskReducer(estadoOriginal, eliminarTarea({ id: 1 }));
    expect(estadoOriginal.items.length).toBe(2); /* no mutado */
    expect(nuevoEstado.items.length).toBe(1);
  });
});


/* ═══════════════════════════════════════════════════════════
   VOTE REDUCER TESTS
   ═══════════════════════════════════════════════════════════ */
describe('voteReducer', () => {

  const votoA: VoteItem = { id: 1, titulo: 'Propuesta A', descripcion: 'Desc', votosPositivos: 0, votosNegativos: 0 };
  const votoB: VoteItem = { id: 2, titulo: 'Propuesta B', descripcion: 'Desc', votosPositivos: 5, votosNegativos: 2 };

  it('debe retornar el estado inicial con los items precargados', () => {
    const state = voteReducer(undefined, { type: '@@UNKNOWN' } as any);
    expect(state.items.length).toBeGreaterThan(0);
  });

  it('agregarVoteItem: debe agregar un nuevo item de votación', () => {
    const estado: VoteState = { items: [] };
    const resultado = voteReducer(estado, agregarVoteItem({ item: votoA }));
    expect(resultado.items.length).toBe(1);
    expect(resultado.items[0].titulo).toBe('Propuesta A');
  });

  it('eliminarVoteItem: debe eliminar el item con el id indicado', () => {
    const estado: VoteState = { items: [votoA, votoB] };
    const resultado = voteReducer(estado, eliminarVoteItem({ id: 1 }));
    expect(resultado.items.length).toBe(1);
    expect(resultado.items[0].id).toBe(2);
  });

  it('votarPositivo: debe incrementar votosPositivos del item correcto', () => {
    const estado: VoteState = { items: [votoA, votoB] };
    const resultado = voteReducer(estado, votarPositivo({ id: 1 }));

    expect(resultado.items[0].votosPositivos).toBe(1);
    expect(resultado.items[1].votosPositivos).toBe(5); /* no debe cambiar */
  });

  it('votarNegativo: debe incrementar votosNegativos del item correcto', () => {
    const estado: VoteState = { items: [votoA, votoB] };
    const resultado = voteReducer(estado, votarNegativo({ id: 2 }));

    expect(resultado.items[1].votosNegativos).toBe(3);
    expect(resultado.items[0].votosNegativos).toBe(0); /* no debe cambiar */
  });

  it('votarPositivo: NO debe mutar el estado original', () => {
    const estadoOriginal: VoteState = { items: [{ ...votoA }] };
    const nuevoEstado = voteReducer(estadoOriginal, votarPositivo({ id: 1 }));

    expect(estadoOriginal.items[0].votosPositivos).toBe(0); /* no mutado */
    expect(nuevoEstado.items[0].votosPositivos).toBe(1);
    expect(nuevoEstado).not.toBe(estadoOriginal);
  });

  it('votarNegativo: NO debe mutar el estado original', () => {
    const estadoOriginal: VoteState = { items: [{ ...votoA }] };
    const nuevoEstado = voteReducer(estadoOriginal, votarNegativo({ id: 1 }));

    expect(estadoOriginal.items[0].votosNegativos).toBe(0); /* no mutado */
    expect(nuevoEstado.items[0].votosNegativos).toBe(1);
  });
});


/* ═══════════════════════════════════════════════════════════
   TRACKING REDUCER TESTS
   ═══════════════════════════════════════════════════════════ */
describe('trackingReducer', () => {

  it('debe retornar el estado inicial vacío', () => {
    const state = trackingReducer(undefined, { type: '@@UNKNOWN' } as any);
    expect(state).toEqual(initialTrackingState);
    expect(state.totalClicks).toBe(0);
    expect(Object.keys(state.contadores).length).toBe(0);
  });

  it('registrarClick: debe crear un nuevo contador para un tag nuevo', () => {
    const resultado = trackingReducer(initialTrackingState, registrarClick({ tag: 'btn-test' }));
    expect(resultado.contadores['btn-test']).toBe(1);
    expect(resultado.totalClicks).toBe(1);
  });

  it('registrarClick: debe incrementar el contador de un tag existente', () => {
    const estado1 = trackingReducer(initialTrackingState, registrarClick({ tag: 'btn-test' }));
    const estado2 = trackingReducer(estado1,              registrarClick({ tag: 'btn-test' }));
    const estado3 = trackingReducer(estado2,              registrarClick({ tag: 'btn-test' }));

    expect(estado3.contadores['btn-test']).toBe(3);
    expect(estado3.totalClicks).toBe(3);
  });

  it('registrarClick: debe manejar múltiples tags independientemente', () => {
    let state = trackingReducer(initialTrackingState, registrarClick({ tag: 'tag-A' }));
    state = trackingReducer(state, registrarClick({ tag: 'tag-B' }));
    state = trackingReducer(state, registrarClick({ tag: 'tag-A' }));

    expect(state.contadores['tag-A']).toBe(2);
    expect(state.contadores['tag-B']).toBe(1);
    expect(state.totalClicks).toBe(3);
  });

  it('registrarClick: NO debe mutar el estado original', () => {
    const estadoOriginal: TrackingState = { contadores: {}, totalClicks: 0 };
    const nuevoEstado = trackingReducer(estadoOriginal, registrarClick({ tag: 'tag-X' }));

    expect(estadoOriginal.totalClicks).toBe(0);
    expect(estadoOriginal.contadores['tag-X']).toBeUndefined();
    expect(nuevoEstado.totalClicks).toBe(1);
  });

  it('resetTracking: debe volver al estado inicial', () => {
    let state = trackingReducer(initialTrackingState, registrarClick({ tag: 'tag-A' }));
    state = trackingReducer(state, registrarClick({ tag: 'tag-B' }));
    expect(state.totalClicks).toBe(2);

    const resetState = trackingReducer(state, resetTracking());
    expect(resetState.totalClicks).toBe(0);
    expect(Object.keys(resetState.contadores).length).toBe(0);
  });
});

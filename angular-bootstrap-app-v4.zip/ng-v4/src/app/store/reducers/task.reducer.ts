/* store/reducers/task.reducer.ts — Req #9 anterior */
import { createReducer, on } from '@ngrx/store';
import { Item }              from '../../models/item.model';
import { agregarTarea, eliminarTarea, cargarTareas } from '../actions/task.actions';

export interface TaskState { items: Item[]; }

export const initialTaskState: TaskState = { items: [] };

export const taskReducer = createReducer(
  initialTaskState,
  on(cargarTareas,  (state, { items }) => ({ ...state, items })),
  on(agregarTarea,  (state, { item  }) => ({ ...state, items: [...state.items, item] })),
  on(eliminarTarea, (state, { id   }) => ({ ...state, items: state.items.filter(i => i.id !== id) }))
);

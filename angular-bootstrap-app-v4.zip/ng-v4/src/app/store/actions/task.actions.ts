/* store/actions/task.actions.ts */
import { createAction, props } from '@ngrx/store';
import { Item, VoteItem }      from '../../models/item.model';

/* Task actions */
export const agregarTarea   = createAction('[Tasks] Agregar Tarea',   props<{ item: Item }>());
export const eliminarTarea  = createAction('[Tasks] Eliminar Tarea',  props<{ id: number }>());
export const cargarTareas   = createAction('[Tasks] Cargar Tareas',   props<{ items: Item[] }>());

/* Vote actions */
export const agregarVoteItem = createAction('[Votes] Agregar Item',   props<{ item: VoteItem }>());
export const eliminarVoteItem= createAction('[Votes] Eliminar Item',  props<{ id: number }>());
export const votarPositivo   = createAction('[Votes] Votar Positivo', props<{ id: number }>());
export const votarNegativo   = createAction('[Votes] Votar Negativo', props<{ id: number }>());

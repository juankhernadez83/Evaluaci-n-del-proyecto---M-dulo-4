/*
  store/actions/tracking.actions.ts
  Req #7: Actions para actualizar contadores de tracking tags en Redux
*/
import { createAction, props } from '@ngrx/store';

export const registrarClick = createAction(
  '[Tracking] Registrar Click',
  props<{ tag: string }>()
);

export const resetTracking = createAction('[Tracking] Reset');

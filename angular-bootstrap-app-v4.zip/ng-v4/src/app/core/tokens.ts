/* core/tokens.ts — Req #3: InjectionToken propio */
import { InjectionToken } from '@angular/core';

export interface AppConfig {
  apiUrl:    string;
  appNombre: string;
  version:   string;
  maxItems:  number;
}

/** Req #3: InjectionToken para configuración global */
export const APP_CONFIG = new InjectionToken<AppConfig>('APP_CONFIG');

export const APP_CONFIG_VALUE: AppConfig = {
  apiUrl:    'http://localhost:3000/api',
  appNombre: 'Gestor de Tareas',
  version:   '2.0.0',
  maxItems:  100,
};

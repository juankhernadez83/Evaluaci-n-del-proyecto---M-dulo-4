/* core/logger.ts — Req #4: useClass  |  Req #5: useExisting */
import { Injectable } from '@angular/core';

/** Clase base Z — ambas subclases heredan de aquí (Req #5) */
@Injectable()
export class BaseLoggerService {
  protected prefix = '[App]';
  log(msg: string):   void { console.log(`${this.prefix} ${msg}`); }
  warn(msg: string):  void { console.warn(`${this.prefix} ⚠️ ${msg}`); }
  error(msg: string): void { console.error(`${this.prefix} ❌ ${msg}`); }
}

/**
 * Req #4: Token de inyección.
 * En AppModule: { provide: LoggerService, useClass: ConsoleLoggerService }
 */
@Injectable()
export class LoggerService extends BaseLoggerService {}

/**
 * Req #4: Clase concreta que se vincula via useClass.
 * Hereda de BaseLoggerService (clase Z).
 */
@Injectable()
export class ConsoleLoggerService extends BaseLoggerService {
  override prefix = '[Console]';
  override log(msg: string): void {
    console.log(`%c${this.prefix} ${msg}`, 'color:#4CAF50');
  }
}

/**
 * Req #5: Compatible con ConsoleLoggerService porque ambas heredan de BaseLoggerService.
 * En AppModule: { provide: FileLoggerService, useExisting: ConsoleLoggerService }
 * → reutiliza la instancia existente de ConsoleLoggerService.
 */
@Injectable()
export class FileLoggerService extends BaseLoggerService {
  override prefix = '[File]';
}

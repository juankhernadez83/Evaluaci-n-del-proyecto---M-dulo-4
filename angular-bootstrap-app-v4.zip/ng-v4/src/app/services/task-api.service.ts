/*
  services/task-api.service.ts
  Req #7:  HttpClient asíncrono con la API Express
  Req #8:  Al respuesta exitosa del POST → dispatch agregarTarea a NgRx
  Req #10: Al respuesta exitosa del POST → guardar en Dexie
*/
import { Injectable, Inject } from '@angular/core';
import { HttpClient }         from '@angular/common/http';
import { Store }              from '@ngrx/store';
import { Observable, from }   from 'rxjs';
import { tap, switchMap }     from 'rxjs/operators';

import { APP_CONFIG, AppConfig }       from '../core/tokens';
import { AppDatabase }                 from '../db/app-database';
import { Item }                        from '../models/item.model';
import { agregarTarea, eliminarTarea, cargarTareas } from '../store/actions/task.actions';
import { LoggerService }               from '../core/logger';

@Injectable({ providedIn: 'root' })
export class TaskApiService {

  private apiUrl: string;

  constructor(
    private http:  HttpClient,
    @Inject(APP_CONFIG) private config: AppConfig,  /* Req #3 */
    private store: Store,
    private db:    AppDatabase,                     /* Req #9 */
    private logger: LoggerService                   /* Req #4 */
  ) {
    this.apiUrl = config.apiUrl + '/tasks';
    this.logger.log(`TaskApiService listo. API: ${this.apiUrl}`);
  }

  /** Req #7: GET — carga tareas desde la API y las pone en el store */
  getTareas(): Observable<Item[]> {
    this.logger.log('GET /tasks');
    return this.http.get<Item[]>(this.apiUrl).pipe(
      tap(items => {
        this.logger.log(`GET /tasks → ${items.length} items`);
        this.store.dispatch(cargarTareas({ items }));
      })
    );
  }

  /**
   * Req #7:  POST — envía nuevo ítem a la API Express.
   * Req #8:  Al recibir 201, despacha agregarTarea al store NgRx.
   * Req #10: Al recibir 201, también guarda en Dexie asíncronamente.
   */
  crearTarea(payload: Omit<Item, 'id' | 'fechaCreacion'>): Observable<Item> {
    this.logger.log(`POST /tasks "${payload.nombre}"`);

    return this.http.post<Item>(this.apiUrl, payload).pipe(

      /* Req #8: tap() despacha la action a NgRx cuando la API responde OK */
      tap((itemCreado: Item) => {
        this.logger.log(`✅ API confirmó id=${itemCreado.id}`);
        this.store.dispatch(agregarTarea({ item: itemCreado }));
      }),

      /* Req #10: switchMap encadena el guardado en Dexie */
      switchMap((itemCreado: Item) => {
        const record = {
          apiId:         itemCreado.id,
          nombre:        itemCreado.nombre,
          descripcion:   itemCreado.descripcion,
          categoria:     itemCreado.categoria,
          fechaCreacion: String(itemCreado.fechaCreacion),
          sincronizado:  true
        };
        return from(
          this.db.guardarTarea(record).then(dexieId => {
            this.logger.log(`✅ Dexie guardó tarea dexieId=${dexieId}`);
            return itemCreado;
          })
        );
      })
    );
  }

  /** DELETE — elimina en API, NgRx y Dexie */
  eliminarTarea(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`).pipe(
      tap(() => {
        this.store.dispatch(eliminarTarea({ id }));
        this.db.eliminarPorApiId(id).catch(e => this.logger.error(String(e)));
      })
    );
  }
}

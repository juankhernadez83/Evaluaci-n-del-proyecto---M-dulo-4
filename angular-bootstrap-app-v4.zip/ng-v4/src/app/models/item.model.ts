/* models/item.model.ts */

export interface Item {
  id:            number;
  nombre:        string;
  descripcion:   string;
  categoria:     string;
  fechaCreacion: Date | string;
}

export interface VoteItem {
  id:              number;
  titulo:          string;
  descripcion:     string;
  votosPositivos:  number;
  votosNegativos:  number;
}
